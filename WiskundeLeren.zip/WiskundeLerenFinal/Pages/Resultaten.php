<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Results</title>
    <!-- Include any necessary CSS stylesheets or libraries -->
    <link rel="stylesheet" href="../Styling/styles.css">
    <style>
        .page-body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            overflow-y: auto;
        }

        .chapter-card {
            max-height: 400px;
            background-color: #f5f5f5;
            width: auto; /* Adjust width as needed */
            margin: 30px auto; /* Center the card horizontally */
            border: 1px solid #ccc;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .graph-container {
            display: flex;
            justify-content: center;
            max-height: 200px;
            flex-direction: row;
            align-items: center;
        }

        .graph-container canvas {
            width: 200px; /* Adjust width of the canvas as needed */
            height: 200px; /* Adjust height of the canvas as needed */
        }

        .legend {
            margin-top: 10px;
            list-style: none;
            padding: 0;
        }

        .legend-item {
            display: flex;
            align-items: center;
            margin-bottom: 5px;
        }

        .legend-item span {
            display: inline-block;
            width: 10px;
            height: 10px;
            margin-right: 5px;
            border-radius: 50%;
        }
    </style>
    </style>
</head>
<body>
    <div class="page-body">
        <div class="sticky-bar">
            <div class="logo">Wiskunde Leren</div>
            <ul class="navigation">
            <li><a href="homepage.html" class="nav-link">Over ons</a></li>
                <li><a href="Opgaven.php" class="nav-link">Opgaven</a></li>
                <li><a href="Resultaten.php" class="nav-link">Resultaten</a></li>
                <li>
                    <div class="profile-menu">
                        <div class="profile">
                            <button id="loginBtn" class="button">Login</button>
                        </div>
                        <div id="showOnlyWhenLogged" class="logout-menu-holder">
                            <div class="logout-menu">
                                <a id="logoutLink" href="#">Logout</a>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
        <div class="content">
            <?php
            if (isset($_COOKIE['username'])) {
                $servername = "localhost";
                $username = "root";
                $password = ""; 
                $database = "users"; 
                $conn = new mysqli($servername, $username, $password, $database);

                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $username = $_COOKIE['username'];

                $query = "SELECT DISTINCT chapter FROM scores WHERE username='$username'";
                $result = $conn->query($query);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $chapter = $row['chapter'];

                        $quer = "SELECT name FROM chapters WHERE id='$chapter'";
                        $res = $conn->query($quer);

                        if ($res && $res->num_rows > 0) {
                            $chaptername_row = $res->fetch_assoc();

                            $chaptername = $chaptername_row['name'];

                            echo "<div class='chapter-card'>";
                            echo "<h2>Chapter $chapter - $chaptername</h2>";
                            echo "<div class='graph-container'>";
                        } else {
                            echo "Chapter not found";
                        }

                        
                        $query = "SELECT * FROM scores WHERE username='$username' AND chapter='$chapter'";
                        $result_scores = $conn->query($query);

                        if ($result_scores->num_rows > 0) {
                            echo "<canvas id='myChart$chapter' width='400' height='400'></canvas>";
                            echo "<script src='https://cdn.jsdelivr.net/npm/chart.js'></script>";
                            echo "<script>";
                            echo "var ctx$chapter = document.getElementById('myChart$chapter').getContext('2d');
                                var myChart$chapter = new Chart(ctx$chapter, {
                                    type: 'doughnut',
                                    data: {
                                        datasets: [{
                                            label: 'Scores',
                                            data: [";
                            $goedCount = 0;
                            $gedeeltelijkGoedCount = 0;
                            $foutCount = 0;

                            while ($row_score = $result_scores->fetch_assoc()) {
                                if ($row_score['score'] == 'Goed') {
                                    $goedCount++;
                                } elseif ($row_score['score'] == 'Gedeeltelijk Goed') {
                                    $gedeeltelijkGoedCount++;
                                } elseif ($row_score['score'] == 'fout') {
                                    $foutCount++;
                                }
                            }

                            echo "$goedCount, $gedeeltelijkGoedCount, $foutCount";
                            echo "],
                                            backgroundColor: [
                                                'rgba(75, 192, 192, 0.2)',
                                                'rgba(255, 205, 86, 0.2)',
                                                'rgba(255, 99, 132, 0.2)'
                                            ],
                                            borderColor: [
                                                'rgba(75, 192, 192, 1)',
                                                'rgba(255, 205, 86, 1)',
                                                'rgba(255, 99, 132, 1)'
                                            ],
                                            borderWidth: 1
                                        }]
                                    },
                                    options: {
                                        scales: {
                                            yAxes: [{
                                                ticks: {
                                                    beginAtZero: true
                                                }
                                            }]
                                        }
                                    }
                                });";
                            echo "</script>";
                            echo "<div class='legend'>";
                            echo "<ul>";
                            echo "<li class='legend-item'><span style='background-color: rgba(75, 192, 192, 0.2);'></span> Goed</li>";
                            echo "<li class='legend-item'><span style='background-color: rgba(255, 205, 86, 0.2);'></span> Gedeeltelijk Goed</li>";
                            echo "<li class='legend-item'><span style='background-color: rgba(255, 99, 132, 0.2);'></span> Fout</li>";
                            echo "</ul>";
                            echo "</div>"; 
                        } else {
                            echo "<p>Geen resultaten voor hoofdstuk $chapter</p>";
                        }
                        echo "</div>"; 
                        echo "</div>"; 
                    }
                } else {
                    echo "<p>Geen resultaten gevonden voor $username</p>";
                }

                $conn->close();
            } else {
                echo "<p>Je moet inloggen om je gegevens op te slaan</p>";
            }
            ?>
        </div> 
    </div> 
</body>
<script src="../Javascript/homepage.js"></script>
</html>
