<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login System</title>
    <link rel="stylesheet" href="../Styling/styles.css">
</head>
<body>
    <?php
        if(isset($_COOKIE['username'])) {
            $username = $_COOKIE['username'];
            header('Location: homepage.html');
            exit;
        } 

        session_start();
        $message = null;

        if (isset($_SESSION['message'])) {
            $message = $_SESSION['message'];
            unset($_SESSION['message']);
        } 
        echo "<script>";
        echo "var message = '" . $message . "';";
        echo "</script>";
    ?>
    <div class="container">
        <div class="forms">
            <div id="login">
                <form id="loginForm" action="login.php" method="POST" style="margin: 0px">
                    <h2>Login</h2>
                    <div class="form-row">
                        <input type="text" id="loginUsername" name="loginUsername" placeholder="Username" required>
                        <label class="input-label" for="loginUsername">Username</label>
                    </div>
                    <div class="form-row">
                        <input type="password" id="loginPassword" name="loginPassword" placeholder="Password" required>
                        <label class="input-label" for="loginPassword">Password</label>
                    </div>
                    <div class="form-row forgot-password">
                        <a href="#" id="forgotPasswordLink">Forgot password?</a>
                    </div>
                    <div class="form-row">
                        <button type="submit" class="login-btn">Login</button>
                    </div>
                </form>

                <div class="form-row or-register">
                    <button id="registerBtn" class="register-btn">Register</button>
                </div>
                <div id="incorrect-password" style="color: red; display: none">
                    <label id="incorrect-password">Something is incorrect</label>
                </div>
            </div>
            
            
            <div id="register" style="display: none">
                <form id="registerForm" action="register.php" method="POST" style="margin: 0px">
                    <h2>Register</h2>
                    <div class="form-row">
                        <input type="text" id="registerUsername" name="registerUsername" placeholder="Username" required>
                        <label class="input-label" for="registerUsername">Username</label>
                    </div>
                    <div class="form-row">
                        <input type="email" id="registerEmail" name="registerEmail" placeholder="Email" required>
                        <label class="input-label" for="registerEmail">Email</label>
                    </div>
                    <div class="form-row">
                        <input type="password" id="registerPassword" name="registerPassword" placeholder="Password" required>
                        <label class="input-label" for="registerPassword">Password</label>
                    </div>
                    <div class="form-row">
                        <button type="submit" id="createAccount" class="register-btn">Register</button>
                    </div>
                </form>
                <div class="form-row or-login">
                    <button id="loginBtn" class="login-btn">Login</button>
                </div>
                <label id="failRegisterText">Something went wrong</label>
            </div>
            <div id="forgotPasswordForm" style="display: none">
                <form id="forgotPasswordForm" action="forgot_password.php" method="POST" style="margin: 0px">
                    <h2>Forgot Password</h2>
                    <div class="form-row">
                        <input type="text" id="forgotUsername" name="forgotUsername" placeholder="Username" required>
                        <label class="input-label" for="forgotUsername">Username</label>
                    </div>
                    <div class="form-row">
                        <input type="email" id="forgotEmail" name="forgotEmail" placeholder="Email" required>
                        <label class="input-label" for="forgotEmail">Email</label>
                    </div>
                    <div class="form-row">
                        <input type="password" id="newPassword" name="newPassword" placeholder="New Password" required>
                        <label class="input-label" for="newPassword">New Password</label>
                    </div>
                    <div class="form-row">
                        <input type="password" id="confirmNewPassword" name="confirmNewPassword" placeholder="Confirm New Password" required>
                        <label class="input-label" for="confirmNewPassword">Confirm New Password</label>
                    </div>
                    <div class="form-row">
                        <button type="submit" id="resetPasswordBtn" class="register-btn">Reset Password</button>
                    </div>
                </form>
                <div class="form-row or-login">
                    <button id="loginBtn" class="login-btn">Login</button>
                </div>
            </div>
        </div>
    </div>
    <script src="../Javascript/loginMenu.js"></script>
</body>
</html>
