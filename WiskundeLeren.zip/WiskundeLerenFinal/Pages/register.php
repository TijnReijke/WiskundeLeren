<?php
$servername = "localhost";
$username = "root";
$password = ""; 
$database = "users";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$username = $conn->real_escape_string($_POST['registerUsername']);
$email = $conn->real_escape_string($_POST['registerEmail']);
$password = $conn->real_escape_string($_POST['registerPassword']);

$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

$sqlCheckEmail = "SELECT * FROM logininfo WHERE email = ?";
$stmtCheckEmail = $conn->prepare($sqlCheckEmail);
$stmtCheckEmail->bind_param("s", $email);
$stmtCheckEmail->execute();
$resultCheckEmail = $stmtCheckEmail->get_result();

$sqlCheckUsername = "SELECT * FROM logininfo WHERE username = ?";
$stmtCheckUsername = $conn->prepare($sqlCheckUsername);
$stmtCheckUsername->bind_param("s", $username);
$stmtCheckUsername->execute();
$resultCheckUsername = $stmtCheckUsername->get_result();

if ($resultCheckEmail->num_rows > 0 || $resultCheckUsername->num_rows > 0) {
    session_start();
    $_SESSION['message'] = 'Register';

    header("Location: loginIndex.php");
    exit;
    echo "Error: Email already exists in the database.";
} else {
    $sql = "INSERT INTO logininfo (username, email, password) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $username, $email, $hashedPassword);

    if ($stmt->execute()) {
        session_start();
        $_SESSION['message'] = 'RegisterSuccess';

        header("Location: loginIndex.php");
        exit;
        echo "Registration successful!";
    } else {
        echo "Error: Registration failed.";
    }
    $stmt->close();
}

$stmtCheckEmail->close();
$conn->close();

function generateVerificationCode() {
    return bin2hex(random_bytes(16));
}
?>