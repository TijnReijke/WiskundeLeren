<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Opgaven</title>
    <link rel="stylesheet" href="../Styling/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Permanent+Marker&display=swap" rel="stylesheet">
    <style>
        .page-body{
            overflow-y: auto;
        }
    </style>
</head>
<body>
<div class="page-body">
    <div class="sticky-bar">
        <div class="logo">Wiskunde Leren</div>
        <ul class="navigation">
            <li><a href="homepage.html" class="nav-link">Over ons</a></li>
            <li><a href="Opgaven.php" class="nav-link">Opgaven</a></li>
            <li><a href="Resultaten.php" class="nav-link">Resultaten</a></li>
            <li>
                <div class="profile-menu">
                    <div class="profile">
                        <button id="loginBtn" class="button">Login</button> 
                    </div>
                    <div id="showOnlyWhenLogged" class="logout-menu-holder">
                        <div class="logout-menu">
                            <a id="logoutLink" href="#">Logout</a>
                        </div>
                    </div>
                </div>
            </li>
        </ul>
    </div>

    <div class="content">
        <div class="container">
            <div class="navigation">
                <ul>
                    <li><a href="?chapter_id=1">Hoofdstuk 1 - Afgeleiden</a></li>
                    <li><a href="?chapter_id=2">Hoofdstuk 2 - Transformaties</a></li>
                </ul>
            </div>
            <div class="cards">
                <?php
                $servername = "localhost";
                $username = "root";
                $password = ""; 
                $database = "users"; 

                $conn = new mysqli($servername, $username, $password, $database);

                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }
                function getAssignmentsForChapter($chapter_id, $conn) {
                    $query = "SELECT title, description, opgavenId FROM opgaven WHERE chapterId = $chapter_id";
                    $result = mysqli_query($conn, $query);
                    $assignments = mysqli_fetch_all($result, MYSQLI_ASSOC);
                    return $assignments;
                }

                $chapter_id = isset($_GET['chapter_id']) ? $_GET['chapter_id'] : 1; 
                $assignments = getAssignmentsForChapter($chapter_id, $conn);

                foreach ($assignments as $assignment) {
                    $id = $assignment['opgavenId']; 
                    $title = $assignment['title'];
                    $description = $assignment['description'];
                    echo "<div class='card'>
                            <div class='card-content'>
                                <h2>$title</h2>
                                <p>$description</p>
                            </div>
                            <a class='make-btn' href='assignment.php?assignment_id=$id'>Make</a>
                        </div>";
                }

                $conn->close();
                ?>
            </div>
        </div>
    </div>
</div>
<script src="../Javascript/homepage.js"></script>
</body>
</html>
