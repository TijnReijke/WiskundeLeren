<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "users"; 

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $username = $_POST["loginUsername"];
    $password = $_POST["loginPassword"];

    $sql = "SELECT password FROM logininfo WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $hashed_password = $row["password"];
        
        if (password_verify($password, $hashed_password)) {
            setcookie("username", $username, time() + (86400 * 30), "/"); 
            header("Location: homepage.html"); 
            exit();
        } 
    } 
    session_start();
    $_SESSION['message'] = 'loginFailed';

    header("Location: loginIndex.php");
    exit;
    $conn->close();
}
?>

