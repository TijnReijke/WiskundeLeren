<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignment</title>
    <link rel="stylesheet" href="../Styling/styles.css">
    <style>
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .content {
            overflow: scroll;
        }
    </style>
</head>
<body>
<div class="page-body">
    <div class="sticky-bar">
        <div class="logo">Wiskunde Leren</div>
        <ul class="navigation">
        <li><a href="homepage.html" class="nav-link">Over ons</a></li>
            <li><a href="Opgaven.php" class="nav-link">Opgaven</a></li>
            <li><a href="Resultaten.php" class="nav-link">Resultaten</a></li>
            <li>
                <div class="profile-menu">
                    <div class="profile">
                        <button id="loginBtn" class="button">Login</button> 
                    </div>
                    <div id="showOnlyWhenLogged" class="logout-menu-holder">
                        <div class="logout-menu">
                            <a id="logoutLink" href="#">Logout</a>
                        </div>
                    </div>
                </div>
            </li>
        </ul>
    </div>
    <div class="content">
        <div class="container-question">
            <?php
            $servername = "localhost";
            $username = "root";
            $password = ""; 
            $database = "users"; 

            $conn = new mysqli($servername, $username, $password, $database);

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            function getAssignment($assignment_id, $conn) {
                $query = "SELECT title, question, theory, answer, chapterId FROM opgaven WHERE opgavenId = $assignment_id";
                $result = $conn->query($query);
                if ($result->num_rows > 0) {
                    return $result->fetch_assoc();
                } else {
                    return false;
                }
            }

            $assignment_id = isset($_GET['assignment_id']) ? $_GET['assignment_id'] : 1; 
            $assignment = getAssignment($assignment_id, $conn);
            $chapter_id = $assignment['chapterId'];
            
            if ($assignment) {
                echo "<div class='assignment-container'>";
                echo "<h2 class='assignment-title'>{$assignment['title']}</h2>";
                echo "<div class='assignment-card'>";
                echo "<div class='theory-card'>";
                echo "<h3>Theorie</h3>";
                echo "<p>" . formatExponents($assignment['theory']) . "</p>";
                echo "</div>"; 
                echo "<div class='question-card'>";
                echo "<h3>Vraag</h3>";
                echo "<p>" . formatExponents($assignment['question']) . "</p>";
                echo "</div>"; 
            
                $existingScore = checkIfScoreExist($conn, $assignment_id, $chapter_id);
                if (isset($_POST['submit']) || $existingScore !== null) {
                    if (isset($_POST['submit'])) {
                        $user_answer = $_POST['answer'];
                    } elseif ($existingScore !== null) {
                        $user_answer = $existingScore;
                    }

                    $correct_answer = $assignment['answer'];
                    similar_text($user_answer, $correct_answer, $similarity);
                    $threshold = 50;

                    if ($user_answer == $correct_answer) {
                        $lightColor = '#82e0aa';
                        $color = '#2ecc71'; 
                        $score = 'Goed';
                    } elseif ($similarity >= $threshold) {
                        $lightColor = '#fff6c9';
                        $color = '#ffe253'; 
                        $score = 'Gedeeltelijk Goed';
                    } else {
                        $lightColor = '#ffadad'; 
                        $color = '#ff7373';     
                        $score = 'fout';            
                    }
                    if (isset($_POST['submit'])) {
                        scoreToDatabase($conn, $assignment_id, $score, $chapter_id, $user_answer);
                    }
                    echo "<form method='POST'>";
                    echo "<textarea class='text-field' id='answer' name='answer' style='background-color: $lightColor; border-color: $color;' readonly>$user_answer</textarea><br>";
                    echo "</form>";
                    echo "<p>Goede antwoord: " . formatExponents($correct_answer) . "</p>";
                }else {
                    echo "<form id='submitForm' method='POST'>";
                    echo "<textarea class='text-field' type='text' id='answer' name='answer'></textarea><br>";
                    echo "<input class='submit-btn' type='submit' name='submit' value='Submit'>";
                    echo "</form>";
                }
                echo "</div>"; 
                echo "</div>"; 
            } else {
                echo "<p>Assignment not found!</p>";
            }

            $conn->close();
            function checkIfScoreExist($conn, $assignment_id, $chapter){
                if(isset($_COOKIE['username'])) {
                    $username = $_COOKIE['username'];

                    $query = "SELECT * FROM scores WHERE username='$username'";
                    $result = $conn->query($query);
                    $question_id = $assignment_id;

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            if ($row['questionId'] == $question_id && $row['chapter'] == $chapter) {
                                return strval($row['answer']);
                            }
                        }
                    } 
                    return null;
                }
                return null;
            }
            function scoreToDatabase($conn, $assignment_id, $score, $chapter, $answer){
                if(isset($_COOKIE['username'])) {
                    $username = $_COOKIE['username'];

                    $query = "SELECT questionId, chapter FROM scores WHERE username='$username'";
                    $result = $conn->query($query);
                    $question_id = $assignment_id;

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            if ($row['questionId'] == $question_id && $row['chapter'] == $chapter) {
                                return;
                            }
                        }
                    } 
                    $escaped_answer = $conn->real_escape_string($answer);

                    $sql = "INSERT INTO scores (username, questionId, chapter, score, answer) VALUES ('$username', '$question_id', '$chapter', '$score', '$escaped_answer')";
                    $result = $conn->query($sql);
                }

            }
            function formatExponents($text) {
                $pattern = '/\^(\S+|\{[^{}]+\})/';
                $text = preg_replace_callback($pattern, function($matches) {
                    $exponent = trim($matches[1], '{}');
                    return '<sup>' . $exponent . '</sup>';
                }, $text);
                return $text;
            }
            ?>
        </div> 
    </div>
</div>
</body>
    <script src="../Javascript/homepage.js"> setTimeout(function() {
    // Refresh the page after 3000 milliseconds (3 seconds)
    window.location.reload(); // or window.location.href = "your_url";
}, 3000); // 3
    </script>
</html>
