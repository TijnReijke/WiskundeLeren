<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "users";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $email = $_POST["forgotEmail"];
    $username = $_POST["forgotUsername"];
    $newPassword = $_POST["newPassword"];
    $repeatNewPassword = $_POST["confirmNewPassword"];

    if ($newPassword !== $repeatNewPassword) {
        $_SESSION['message'] = 'PasswordsDoNotMatch';
        header("Location: loginIndex.php");
        exit;
    }

    $sql = "SELECT * FROM logininfo WHERE email = '$email' AND username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $hashed_password = password_hash($newPassword, PASSWORD_DEFAULT);
        $updateSql = "UPDATE logininfo SET password = '$hashed_password' WHERE email = '$email' AND username = '$username'";
        if ($conn->query($updateSql) === TRUE) {
            $_SESSION['message'] = 'PasswordResetSuccess';
            header("Location: loginIndex.php");
            exit;
        } else {
            $_SESSION['message'] = 'PasswordResetFailed';
            header("Location: loginIndex.php");
            exit;
        }
    } else {
        $_SESSION['message'] = 'EmailUsernameMismatch';
        header("Location: loginIndex.php");
        exit;
    }

    $conn->close();
}
?>
