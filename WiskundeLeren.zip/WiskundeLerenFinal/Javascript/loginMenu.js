const usernameInput = document.getElementById('loginUsername');
const passwordInput = document.getElementById('loginPassword');

function toggleLabelVisibility(inputElement) {
    const placeholderLabel = inputElement.previousElementSibling;
    if (placeholderLabel) {
        if (inputElement.value.trim() === '') {
            placeholderLabel.style.visibility = 'visible';
        } else {
            placeholderLabel.style.visibility = 'hidden';
        }
    }
}

usernameInput.addEventListener('input', function() {
    toggleLabelVisibility(usernameInput);
});

passwordInput.addEventListener('input', function() {
    toggleLabelVisibility(passwordInput);
});

toggleLabelVisibility(usernameInput);
toggleLabelVisibility(passwordInput);

const registerBtn = document.getElementById('registerBtn');
const backToLoginBtns = document.querySelectorAll('#loginBtn');
const registerForm = document.getElementById('register');
const loginForm = document.getElementById('login');
const forgotPasswordForm = document.getElementById('forgotPasswordForm');
const forgotPasswordLink = document.getElementById('forgotPasswordLink');
const forgotPasswordBtn = document.getElementById('forgotPasswordBtn'); 
const failRegisterText = document.getElementById('failRegisterText');
const loginFailedLabel = document.getElementById('incorrect-password');

registerForm.style.display = 'none';
forgotPasswordForm.style.display = 'none';
failRegisterText.style.display = 'none';
loginFailedLabel.style.display = 'none';

if (message != null){
    switch(message){
        case 'Register':
            showRegister();
            failRegisterText.style.display = 'block';
            break;
        case 'loginFailed':
            showLogin();
            loginFailedLabel.style.display = 'block';
            break;
        case 'PasswordResetSuccess':
            showLogin();
            alert("Password Changed succesfully");
            break;
        case 'PasswordResetFailed':
            showForgotPassword();
            alert("Password reset failed");
            break;
        case 'EmailUsernameMismatch':
            showForgotPassword();
            alert("Username and Email do not match");
            break;
        case 'PasswordsDoNotMatch':
            showForgotPassword();
            alert("passwords do not match");
            break;
    }
}

registerBtn.addEventListener('click', () => {
    showRegister();
});


backToLoginBtns.forEach(btn => {
    btn.addEventListener('click', function() {
        window.location.href = 'loginIndex.php';
    });
});
forgotPasswordLink.addEventListener('click', (e) => {
    e.preventDefault(); 
    showForgotPassword();
});

forgotPasswordBtn.addEventListener('click', () => {
    showForgotPassword();
});

function showLogin() {
    registerForm.style.display = 'none';
    loginForm.style.display = 'block';
    forgotPasswordForm.style.display = 'none'; 
}

function showRegister() {
    registerForm.style.display = 'block';
    loginForm.style.display = 'none';
    forgotPasswordForm.style.display = 'none'; 
}

function showForgotPassword() {
    registerForm.style.display = 'none';
    loginForm.style.display = 'none';
    forgotPasswordForm.style.display = 'block';
}

function validateRegisterForm() {
    const username = document.getElementById('registerUsername').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;

    if (!username || !email || !password) {
        alert('Please fill out all fields before proceeding.');
        return false;
    }
    return true;
}
