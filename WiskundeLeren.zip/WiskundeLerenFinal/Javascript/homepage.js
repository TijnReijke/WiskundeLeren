var isLoggedIn = false;

const username = getCookie('username');
if (username) {
    isLoggedIn = true;
    console.log('Username cookie found:', username);
} else {
    console.log('Username cookie not found');
}

const profileContainer = document.querySelector('.profile');

function updateProfile(isLoggedIn) {
    profileContainer.innerHTML = '';

    const dissapear = document.getElementById('showOnlyWhenLogged');

    if (isLoggedIn) {
        dissapear.style.display = 'block';
        const profileName = document.createElement('span');
        profileName.textContent = username;
        profileName.classList.add("profile-name");

        const profilePicture = document.createElement('img');
        profilePicture.src = '../Styling/user.png'; 
        profilePicture.alt = 'Profile Picture';
        profilePicture.classList.add('profile-picture');
        
        profileContainer.appendChild(profilePicture);
        profileContainer.appendChild(profileName);
        
    } else {
        const findelement = document.querySelector('logout-menu');
        if (findelement){
            findelement.remove();
        }

        dissapear.style.display = 'none';
        const loginButton = document.createElement('button');
        loginButton.textContent = 'Login';
        loginButton.classList.add('button');
        loginButton.id = 'loginBtn';

        profileContainer.appendChild(loginButton);
    }
}

updateProfile(isLoggedIn);


function getCookie(cookieName) {
    const cookies = document.cookie.split(';');

    for (let i = 0; i < cookies.length; i++) {
        const cookie = cookies[i].trim();

        if (cookie.startsWith(cookieName + '=')) {
            return cookie.substring(cookieName.length + 1);
        }
    }

    return null;
}

document.getElementById('logoutLink').addEventListener('click', function(event) {
    event.preventDefault();
    
    document.cookie = 'username=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';

    window.location.href = "homepage.html"; 
});

document.addEventListener('DOMContentLoaded', function() {
    var loginBtn = document.getElementById('loginBtn');
    if (loginBtn) {
        loginBtn.addEventListener('click', function() {
            window.location.href = '../index.html';
        });
    } 
});




